class RedFalcon_Cards_Base: Inventory_Base
{
	// Include RedFalcon_Cards_Base for ActionStartHelicopter
};